﻿Public Class $safeitemname$




    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'SHOPDATADataSet.ISSUECAT' table. You can move, or remove it, as needed.
        Me.ISSUECATTableAdapter.Fill(Me.SHOPDATADataSet.ISSUECAT)
        'TODO: This line of code loads data into the 'SHOPDATADataSet.users' table. You can move, or remove it, as needed.
        Me.UsersTableAdapter.Fill(Me.SHOPDATADataSet.users)
        'TODO: This line of code loads data into the 'SHOPDATADataSet.DOCKDATA' table. You can move, or remove it, as needed.
        Me.Label4.Text = "USER: " & Environment.UserName
    End Sub


    Private Sub SHOPTextBox_KeyDown(sender As Object, e As KeyEventArgs) Handles SHOPTextBox.KeyDown
        If e.KeyValue = Keys.Enter Then
            If Len(Replace(SHOPTextBox.Text, "Q", "Q0")) < 5 Then SHOPTextBox.Text = "0" & SHOPTextBox.Text
            Me.DOCKDATATableAdapter.Fill(Me.SHOPDATADataSet.DOCKDATA, SN:=SHOPTextBox.Text)
        End If
    End Sub

End Class
