﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class $safeitemname$
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.SHOPLABEL = New System.Windows.Forms.Label()
        Me.SHOPTextBox = New System.Windows.Forms.TextBox()
        Me.DOCKDATABindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.BindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.SHOPDATADataSet = New $rootnamespace$.SHOPDATADataSet()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.WOLabel = New System.Windows.Forms.Label()
        Me.SubmitButton = New System.Windows.Forms.Button()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.ISSUECATBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.CheckBox2 = New System.Windows.Forms.CheckBox()
        Me.CheckBox3 = New System.Windows.Forms.CheckBox()
        Me.CheckBox4 = New System.Windows.Forms.CheckBox()
        Me.ComboBox2 = New System.Windows.Forms.ComboBox()
        Me.UsersBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DOCKDATATableAdapter = New $rootnamespace$.SHOPDATADataSetTableAdapters.DOCKDATATableAdapter()
        Me.DOCKDATABindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.UsersTableAdapter = New $rootnamespace$.SHOPDATADataSetTableAdapters.usersTableAdapter()
        Me.ISSUECATTableAdapter = New $rootnamespace$.SHOPDATADataSetTableAdapters.ISSUECATTableAdapter()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.ComboBox3 = New System.Windows.Forms.ComboBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.SNLOTDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.QTYDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.DOCKDATABindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SHOPDATADataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ISSUECATBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.UsersBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DOCKDATABindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'SHOPLABEL
        '
        Me.SHOPLABEL.AutoSize = True
        Me.SHOPLABEL.Location = New System.Drawing.Point(54, 36)
        Me.SHOPLABEL.Name = "SHOPLABEL"
        Me.SHOPLABEL.Size = New System.Drawing.Size(40, 13)
        Me.SHOPLABEL.TabIndex = 0
        Me.SHOPLABEL.Text = "SHOP:"
        '
        'SHOPTextBox
        '
        Me.SHOPTextBox.Location = New System.Drawing.Point(100, 33)
        Me.SHOPTextBox.Name = "SHOPTextBox"
        Me.SHOPTextBox.Size = New System.Drawing.Size(121, 20)
        Me.SHOPTextBox.TabIndex = 1
        Me.SHOPTextBox.Text = "-"
        '
        'DOCKDATABindingSource
        '
        Me.DOCKDATABindingSource.DataMember = "DOCKDATA"
        Me.DOCKDATABindingSource.DataSource = Me.BindingSource1
        '
        'BindingSource1
        '
        Me.BindingSource1.DataSource = Me.SHOPDATADataSet
        Me.BindingSource1.Position = 0
        '
        'SHOPDATADataSet
        '
        Me.SHOPDATADataSet.DataSetName = "SHOPDATADataSet"
        Me.SHOPDATADataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.BackgroundColor = System.Drawing.SystemColors.ControlLightLight
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.ColumnHeadersVisible = False
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.SNLOTDataGridViewTextBoxColumn, Me.QTYDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.DOCKDATABindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(100, 68)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.RowHeadersVisible = False
        Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView1.Size = New System.Drawing.Size(140, 225)
        Me.DataGridView1.TabIndex = 2
        '
        'WOLabel
        '
        Me.WOLabel.AutoSize = True
        Me.WOLabel.Location = New System.Drawing.Point(14, 68)
        Me.WOLabel.Name = "WOLabel"
        Me.WOLabel.Size = New System.Drawing.Size(83, 13)
        Me.WOLabel.TabIndex = 3
        Me.WOLabel.Text = "WORKORDER:"
        '
        'SubmitButton
        '
        Me.SubmitButton.Location = New System.Drawing.Point(830, 270)
        Me.SubmitButton.Name = "SubmitButton"
        Me.SubmitButton.Size = New System.Drawing.Size(75, 23)
        Me.SubmitButton.TabIndex = 4
        Me.SubmitButton.Text = "Submit"
        Me.SubmitButton.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.AcceptsReturn = True
        Me.TextBox1.AcceptsTab = True
        Me.TextBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox1.Location = New System.Drawing.Point(334, 68)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TextBox1.Size = New System.Drawing.Size(460, 164)
        Me.TextBox1.TabIndex = 6
        '
        'ComboBox1
        '
        Me.ComboBox1.DataSource = Me.ISSUECATBindingSource
        Me.ComboBox1.DisplayMember = "Field1"
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(334, 12)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox1.TabIndex = 7
        '
        'ISSUECATBindingSource
        '
        Me.ISSUECATBindingSource.DataMember = "ISSUECAT"
        Me.ISSUECATBindingSource.DataSource = Me.SHOPDATADataSet
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(263, 44)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(65, 13)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "ASSIGNED:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(259, 15)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(69, 13)
        Me.Label2.TabIndex = 9
        Me.Label2.Text = "CATEGORY:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(38, 10)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(56, 13)
        Me.Label3.TabIndex = 10
        Me.Label3.Text = "CERT BY:"
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.CheckBox1.Location = New System.Drawing.Point(798, 155)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.CheckBox1.Size = New System.Drawing.Size(60, 17)
        Me.CheckBox1.TabIndex = 12
        Me.CheckBox1.Text = "SALES"
        Me.CheckBox1.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'CheckBox2
        '
        Me.CheckBox2.AutoSize = True
        Me.CheckBox2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.CheckBox2.Location = New System.Drawing.Point(798, 132)
        Me.CheckBox2.Name = "CheckBox2"
        Me.CheckBox2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.CheckBox2.Size = New System.Drawing.Size(101, 17)
        Me.CheckBox2.TabIndex = 13
        Me.CheckBox2.Text = "ENGINEERING"
        Me.CheckBox2.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.CheckBox2.UseVisualStyleBackColor = True
        '
        'CheckBox3
        '
        Me.CheckBox3.AutoSize = True
        Me.CheckBox3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.CheckBox3.Location = New System.Drawing.Point(798, 109)
        Me.CheckBox3.Name = "CheckBox3"
        Me.CheckBox3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.CheckBox3.Size = New System.Drawing.Size(83, 17)
        Me.CheckBox3.TabIndex = 14
        Me.CheckBox3.Text = "TRAVELER"
        Me.CheckBox3.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.CheckBox3.UseVisualStyleBackColor = True
        '
        'CheckBox4
        '
        Me.CheckBox4.AutoSize = True
        Me.CheckBox4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.CheckBox4.Location = New System.Drawing.Point(798, 178)
        Me.CheckBox4.Name = "CheckBox4"
        Me.CheckBox4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.CheckBox4.Size = New System.Drawing.Size(64, 17)
        Me.CheckBox4.TabIndex = 15
        Me.CheckBox4.Text = "OTHER"
        Me.CheckBox4.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.CheckBox4.UseVisualStyleBackColor = True
        '
        'ComboBox2
        '
        Me.ComboBox2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.ComboBox2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.ComboBox2.DataSource = Me.UsersBindingSource
        Me.ComboBox2.DisplayMember = "USERNAMES"
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Location = New System.Drawing.Point(334, 41)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox2.TabIndex = 16
        Me.ComboBox2.ValueMember = "USERNAMES"
        '
        'UsersBindingSource
        '
        Me.UsersBindingSource.DataMember = "users"
        Me.UsersBindingSource.DataSource = Me.BindingSource1
        '
        'DOCKDATATableAdapter
        '
        Me.DOCKDATATableAdapter.ClearBeforeFill = True
        '
        'DOCKDATABindingSource1
        '
        Me.DOCKDATABindingSource1.DataMember = "DOCKDATA"
        Me.DOCKDATABindingSource1.DataSource = Me.SHOPDATADataSet
        '
        'UsersTableAdapter
        '
        Me.UsersTableAdapter.ClearBeforeFill = True
        '
        'ISSUECATTableAdapter
        '
        Me.ISSUECATTableAdapter.ClearBeforeFill = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(827, 8)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(43, 13)
        Me.Label4.TabIndex = 17
        Me.Label4.Text = "USER: "
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(811, 88)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(46, 13)
        Me.Label5.TabIndex = 18
        Me.Label5.Text = "ISSUES"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'ComboBox3
        '
        Me.ComboBox3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.ComboBox3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.ComboBox3.DataSource = Me.UsersBindingSource
        Me.ComboBox3.DisplayMember = "USERNAMES"
        Me.ComboBox3.FormattingEnabled = True
        Me.ComboBox3.Location = New System.Drawing.Point(100, 6)
        Me.ComboBox3.MaxLength = 20
        Me.ComboBox3.Name = "ComboBox3"
        Me.ComboBox3.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox3.TabIndex = 19
        Me.ComboBox3.ValueMember = "USERNAMES"
        '
        'TextBox2
        '
        Me.TextBox2.AcceptsReturn = True
        Me.TextBox2.AcceptsTab = True
        Me.TextBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox2.Location = New System.Drawing.Point(334, 254)
        Me.TextBox2.Multiline = True
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(460, 39)
        Me.TextBox2.TabIndex = 20
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(331, 238)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(65, 13)
        Me.Label6.TabIndex = 21
        Me.Label6.Text = "SUMMARY:"
        '
        'SNLOTDataGridViewTextBoxColumn
        '
        Me.SNLOTDataGridViewTextBoxColumn.DataPropertyName = "SNLOT"
        Me.SNLOTDataGridViewTextBoxColumn.HeaderText = "SNLOT"
        Me.SNLOTDataGridViewTextBoxColumn.Name = "SNLOTDataGridViewTextBoxColumn"
        Me.SNLOTDataGridViewTextBoxColumn.ReadOnly = True
        Me.SNLOTDataGridViewTextBoxColumn.Width = 90
        '
        'QTYDataGridViewTextBoxColumn
        '
        Me.QTYDataGridViewTextBoxColumn.DataPropertyName = "QTY"
        Me.QTYDataGridViewTextBoxColumn.HeaderText = "QTY"
        Me.QTYDataGridViewTextBoxColumn.Name = "QTYDataGridViewTextBoxColumn"
        Me.QTYDataGridViewTextBoxColumn.ReadOnly = True
        Me.QTYDataGridViewTextBoxColumn.Width = 40
        '
        '$safeitemname$
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(928, 305)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.ComboBox3)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.ComboBox2)
        Me.Controls.Add(Me.CheckBox4)
        Me.Controls.Add(Me.CheckBox3)
        Me.Controls.Add(Me.CheckBox2)
        Me.Controls.Add(Me.CheckBox1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.SubmitButton)
        Me.Controls.Add(Me.WOLabel)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.SHOPTextBox)
        Me.Controls.Add(Me.SHOPLABEL)
        Me.Name = "$safeitemname$"
        Me.Text = "SHIP LOG"
        CType(Me.DOCKDATABindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SHOPDATADataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ISSUECATBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.UsersBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DOCKDATABindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents BindingSource1 As System.Windows.Forms.BindingSource
    Friend WithEvents SHOPDATADataSet As $rootnamespace$.SHOPDATADataSet
    Friend WithEvents SHOPLABEL As System.Windows.Forms.Label
    Friend WithEvents SHOPTextBox As System.Windows.Forms.TextBox
    Friend WithEvents DOCKDATABindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents DOCKDATATableAdapter As $rootnamespace$.SHOPDATADataSetTableAdapters.DOCKDATATableAdapter
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents WOLabel As System.Windows.Forms.Label
    Friend WithEvents DOCKDATABindingSource1 As System.Windows.Forms.BindingSource
    Friend WithEvents SubmitButton As System.Windows.Forms.Button
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents CheckBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox2 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox3 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox4 As System.Windows.Forms.CheckBox
    Friend WithEvents ComboBox2 As System.Windows.Forms.ComboBox
    Friend WithEvents UsersBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents UsersTableAdapter As $rootnamespace$.SHOPDATADataSetTableAdapters.usersTableAdapter
    Friend WithEvents ISSUECATBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents ISSUECATTableAdapter As $rootnamespace$.SHOPDATADataSetTableAdapters.ISSUECATTableAdapter
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents ComboBox3 As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents SNLOTDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents QTYDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn

End Class
